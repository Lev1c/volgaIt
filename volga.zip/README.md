pip install Flask Flask-RESTful Flask-RESTful-Swagger Flask-SQLAlchemy Flask-JWT-Extended
python main.py