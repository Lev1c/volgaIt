from flask_sqlalchemy import SQLAlchemy

app = Flask(__name)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://username:password@localhost/database_name'
db = SQLAlchemy(app)


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)

from flask_jwt_extended import jwt_required, create_access_token, get_jwt_identity, JWTManager
from werkzeug.security import generate_password_hash, check_password_hash


class AccountController(Resource):
    @jwt_required()
    def get(self):
        current_user = get_jwt_identity()
        user = User.query.filter_by(username=current_user).first()
        return jsonify(username=current_user), 200

    def post(self):
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')

        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            access_token = create_access_token(identity=username)
            return jsonify(access_token=access_token), 200
        else:
            return jsonify(message="Invalid username or password"), 401

    def put(self):
        data = request.get_json()
        new_username = data.get('username')
        new_password = data.get('password')
        current_user = get_jwt_identity()

        user = User.query.filter_by(username=current_user).first()
        if not user:
            return jsonify(message="User not found"), 404
        
        if new_username != current_user and User.query.filter_by(username=new_username).first():
            return jsonify(message="Username already exists"), 400

        user.username = new_username
        user.password = generate_password_hash(new_password)
        db.session.commit()
        return jsonify(message="User account updated successfully"), 200
    

from flask_restful_swagger import swagger
from flask_jwt_extended import JWTManager


api = swagger.docs(Api(app), apiVersion='0.1')


app.config['JWT_SECRET_KEY'] = 'your_secret_key'  
jwt = JWTManager(app)


@jwt.user_loader_callback
def user_loader_callback(identity):
    user = User.query.filter_by(username=identity).first()
    return user

@jwt.user_identity_loader
def user_identity_lookup(user):
    return user.username